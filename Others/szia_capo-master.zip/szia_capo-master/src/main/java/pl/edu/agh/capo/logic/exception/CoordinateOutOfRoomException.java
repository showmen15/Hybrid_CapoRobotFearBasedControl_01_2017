package pl.edu.agh.capo.logic.exception;

public class CoordinateOutOfRoomException extends Exception {
}
