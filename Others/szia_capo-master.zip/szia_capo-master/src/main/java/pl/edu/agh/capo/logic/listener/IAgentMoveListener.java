package pl.edu.agh.capo.logic.listener;

import pl.edu.agh.capo.logic.common.AgentMove;

public interface IAgentMoveListener {

    void onAgentMoved(AgentMove move);
}


