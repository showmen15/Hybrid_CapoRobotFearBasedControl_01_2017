package pl.edu.agh.capo.fear.collisions;

import pl.edu.agh.capo.fear.data.Trajectory;

public interface CollisionDetector {

	public int getCollidingTrajecotryStepNumber(Trajectory trajectory);
}
